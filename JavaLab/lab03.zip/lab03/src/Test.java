/**
 * Created by pas114 on 2016-10-20.
 */
public class Test {
    public int getTestNumber() {
        return testNumber;
    }

    public void setTestNumber(int testNumber) {
        this.testNumber = testNumber;
    }

    private int testNumber;

}
