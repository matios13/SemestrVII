import javax.swing.*;
import java.awt.*;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.Arrays;

/**
 * Created by pas114 on 2016-10-20.
 */
public class Panel extends JPanel {
    private JComboBox<Class> classChoser;
    private JComboBox<Method> methodChoser;
    private JTextField value;
    private Object returnValue;
    private Object selectedClass;

    public Panel() {
        setLayout(new FlowLayout());
        classChoser = new JComboBox();
        classChoser.addActionListener(a -> updateMethodsForClass((Class) classChoser.getSelectedItem()));
        methodChoser = new JComboBox();
        methodChoser.addActionListener(a-> setFields(((Method)methodChoser.getSelectedItem()).getParameters()));
        value = new JTextField();
        JButton invokeButton = new JButton();
        System.out.println();
        invokeButton.addActionListener(a -> System.out.println(invokeMethod((Method) methodChoser.getSelectedItem())));
        add(classChoser);
        add(methodChoser);
        add(invokeButton);
        add(value);
    }

    public JComboBox<Class> getClassChoser() {
        return classChoser;
    }

    public void setClassChoser(JComboBox<Class> classChoser) {
        this.classChoser = classChoser;
    }

    public JComboBox<Method> getMethodChoser() {
        return methodChoser;
    }

    public void setMethodChoser(JComboBox<Method> methodChoser) {
        this.methodChoser = methodChoser;
    }

    public JTextField getValue() {
        return value;
    }

    public void setValue(JTextField value) {
        this.value = value;
    }
    public Object invokeMethod(Method m) {
        try {
            return m.invoke(selectedClass);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
        return "null";
    }

    public void setFields(Parameter[] parameters){

    }
    public void updateMethodsForClass(Class c){
        try {
            selectedClass=c.newInstance();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        methodChoser.removeAllItems();
        System.out.println("UPDATE"+methodChoser.getSelectedItem());
        Arrays.stream(c.getMethods()).forEach(m->{
            methodChoser.addItem(m);
            System.out.println(m);
        });

    }
}
